package com.pradeep.bank.model;

public class Account {

}
