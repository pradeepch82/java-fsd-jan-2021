
Day1    23-Jan-2021
====================

JDK 8
=====
https://www.oracle.com/java/technologies/javase/javase8-archive-downloads.html#license-lightbox


STS Download
============
https://download.springsource.com/release/STS4/4.8.1.RELEASE/dist/e4.17/spring-tool-suite-4-4.8.1.RELEASE-e4.17.0-win32.win32.x86_64.self-extracting.jar

Spring Distrubution 5.0
=======================
https://repo.spring.io/release/org/springframework/spring/5.0.2.RELEASE/



Enterprise Application
=======================



Enterprise :(Business Organization) : make the money by providing services
===================================
Banks  :withdraw,deposit,fundTransfer,loan
LICS   :Insurance policy
Transports:book,cancel ticket
Hotels  :order food,book table
Hospitals:appointment
School   :admission,teaching,result
College  :admission,teaching,result


Layer :Logical separation of code
Tier  :Physical separation of code

Applications development platforms

Java
.Net
PHP
Node JS
Python



Database Operation
=====================
C=Create
R=Retrieve
U=Update
D=Delete


fundTransfer:(int source,int destination ,int amount)
             
             1.retireve source and validate amount < avialable
             2.retirve destination and validate 
             3.debit source -update
             4.credit destination -update
             5.commit


Presentation Layer :Code written to provide the input screen and resposne to the user
Service Layer      :Logical implementation of business rules
Data Access Layer  :Code written to access the data from Data source
Data Layer         :It is source for Data   


Three data sources
==================
Collection
MySQL
MongoDB


Data Access Layer : Hibernate
Service Layer     : EJB
Presentation Layer :Struts

Spring -One stop shop application
        It takes care of all layers of enterprise application
         


Banking
=======

Develop a Banking application

Write a Java application to perform standard CRUD operations on Customer and Account 

Account:
        accno
        balance
        doc
        type
        customerId 
        
Customer
        customerId
        name
        pan
        mobile         
        account
        address
        
        
        
         
CustomerMainApp
              CustomerService
                           CustomerDao
                                        MapCustomerServiceImpl
                                                                CustomerMap
                                                                   



Day2  :24-Jan-2021
======
IOC -Inversion of Control -Don't call me I  will call you
DI  -It is a mechanism of initializing the dependencies 

      1.setter injection
      2.constructor injection      
      
      
Step 1: create a Java Project and add spring jar files to class path


Step 2: create a spring container

1.Core Container -BeanFactory based
2.Advanced Container -ApplicationContext
3.Web Container -WebApplicationContext


                             BeanFactory (I)
                                 |
                                 |XMLBeanFactory (C) :Lazy Initialization
                                 |
                            ApplicationContext(I)   :Eager Initialization
                                 |
ClasspatApplicationXMLContext (C)|    AnnotationConfigApplicationContext (C)
                                 |
                                 |
                           ServletWebApplicationContext(I)           


//core container

Lazy Initiialization
XmlBeanFactory c=new XmlBeanFactory(new ClassPathResource("beans.xml"));
         
         
//advanced container
Eager Initialization     
ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans.xml");
	    

<beans default-lazy-init=false|true/>
	    
<bean lazy-init=false|true/>


        
1.get bean by type if only one bean of specific type
  
  CustomerMainApp cma=c.getBean(CustomerMainApp.class);
         
2.get bean by id when multiple beans of same type

CustomerMainApp cma=(CustomerMainApp)c.getBean("customerMainApp");
        




DI :Mechamsim of initialzing the depencencies

  setter   ->    <property name="cs" ref="customerService">

  constructor -> <constructor-arg   name="cs" ref="customerService">
                          
                                                    
Spring Bean Life Cycle
==========================
1.Instantiation
2.Dependency Injection(setter/constructor)
3.Initialization   (init-method)
4.Service
5.Destruction      (destroy-method)

Spring Bean Scope : singleton|prototype|request|session



Spring Bean Scope
==================
<bean  scope="singleton"/>

singleton -Stateless Application
prototype -Stateful Application

request  -web
session  -web


Day3-2-Feb-2021
================
1.Bean Auto wiring
2.Annotation Based configuration


Wiring : Mechanism of associating the beans with each other

Auto Wiring : Mechanism of delegating the process of associating the beans with each other
              to spring container
              
              
 <bean  autowire="no|byName|byType|constructor"/>
              
byName         :Search bean with id matching dependency name
byType         :Search the bean by type with dependency type
constructor    :Similar to byType but instead of using setter it uses constructor injection


Annotation based configuration
=================================
Any class which is marked with below annotation is called as Spring Bean


                                   @Component
                                       |
                                       |
                                       |
     -------------------------------------------------------------------
     |                                 |                               |
   @Controller                     @Service                           @Repository             
     |
     |
   @RestController
         
       
      
      
      
 Controller Bean  :@Controller
 Service Bean     :@Service
 Dao              :@Repository       
 utiltiy class    :@Component           
      
 
  
@Autowire       - <bean  autowire="no|byName|byType|constructor"/>

                  applied to setter method/constructor/or interface


@Qualifier      -   byName
@Postconstruct  -   <bean  init-method="init">
@PreDestroy     -   <bean  destroy-method="destroy">


3-Feb-2021
==========
drop database bank;
create database bank;
use bank;

create table customer(
customerId int primary key,
name text(25),
pan  text(10),
mobile  text(10),
account int,
dateOfBirth date,
address text(100)
);


desc customer;

insert into customer values(101,'ramesh patil','omxos9834f','9727765361',2011,'2011-11-11','Pune');
insert into customer values(102,'sachin patil','amxos9834b','8727765361',2011,'2011-11-12','Pune');
insert into customer values(103,'pradeep patil','xmxos9834a','7727765361',2011,'2011-11-10','Pune');


select * from customer;




CustomerMainApp
              CustomerService
                           CustomerDao
                                        MapCustomerDaoImpl
                                                                CustomerMap

                                        MySQLCustomerDaoImpl
                                                  
                                                   JdbcTemplate                   MySQL        
                                                          DataSource                
                                                                 driverClassName
                                                                 url
                                                                 username
                                                                 password 



ORM -Object Relational Mapping Data
====================================          
+------------+---------------+------------+------------+---------+-------------+---------+
| customerId | name          | pan        | mobile     | account | dateOfBirth | address |
+------------+---------------+------------+------------+---------+-------------+---------+
|        101 | ramesh patil  | omxos9834f | 9727765361 |    2011 | 2011-11-11  | Pune    |
|        102 | sachin patil  | amxos9834b | 8727765361 |    2011 | 2011-11-12  | Pune    |
|        103 | pradeep patil | xmxos9834a | 7727765361 |    2011 | 2011-11-10  | Pune    |
+------------+---------------+------------+------------+---------+-------------+---------+
                  

Customer c=new Customer();
c.setCustomerId(101);
c.setName("ramesh patil");
c.setPan("omxos9834f");
.
.
.
c.setAddress("Pune");


org.springframework.jdbc.core.JdbcTemplate

update - DML
query  -get multiple records
queryForObject -get specific record
      




Day4-3-Feb-2021
================
spring web mvc
===============

url      method      mapping                                                         new style                                             new style
=========================================================================================================
/hello   GET         @RequestMapping(value="/hello",method=RequestMethod.GET)        @GetMapping("/hello")
/hello   POST        @RequestMapping(value="/hello",method=RequestMethod.POST)       @PostMapping("/hello")
/hello   DELETE      @RequestMapping(value="/hello",method=RequestMethod.DELETE)     @DeleteMapping("/hello")
/hello   PUT         @RequestMapping(value="/hello",method=RequestMethod.PUT)        @PutMapping("/hello")
/hello   PATCH       @RequestMapping(value="/hello",method=RequestMethod.PATCH)      @PatchMapping("/hello")


@ResponseBody  => Server to Client => Java Object to JSON or XML  => Accept       = application/json 

@RequestBody  => Client to Server =>  JSON or XML Java Object to  => Content-Type = application/json


For Message Conversion :

Step 1:  add below tag in spring-config file
=======
<mvc:annotation-driven/>

Step 2:  Add below jars in class path
=======
jackson-core-2.9.8
jackson-annotations-2.9.0.jar
jackson-databind-2.9.8.jar


@Controller
@RestController


http://localhost:8080/spring-web-mvc/hello
http://localhost:8080/spring-web-mvc/hello/welcome
http://localhost:8080/spring-web-mvc/hello/greet




http://localhost:8080/spring-web-mvc/rest/customers             =>GET    =>GET ALL CUSTOMERS
http://localhost:8080/spring-web-mvc/rest/customers/101         =>GET    =>GET CUSTOMER WITH ID 101
http://localhost:8080/spring-web-mvc/rest/customers/101         =>PUT    =>UPDATE CUSTOMER WITH ID 101
http://localhost:8080/spring-web-mvc/rest/customers/101         =>DELETE =>DELETE CUSTOMER WITH ID 101
http://localhost:8080/spring-web-mvc/rest/customers             =>POST   =>ADD CUSTOMER


@Controller
@RequestMapping("/hello")
public class HelloController{

@RequestMapping(method=RequestMethod.GET)
public @ResponseBody String hello(){
return "Hello World";
}

@RequestMapping(value="/welcome"method=RequestMethod.GET)
public @ResponseBody String welcome(){
return "Welcome World";
}

@RequestMapping(value="/greet", method=RequestMethod.GET)
public @ResponseBody String greet(){
return "Greett World";
}

}



or @RestController =@Controller + @ResponseBody

@RestController
@RequestMapping("/hello")
public class HelloController{

@RequestMapping(method=RequestMethod.GET)
public  String hello(){
return "Hello World";
}

@RequestMapping(value="/welcome"method=RequestMethod.GET)
public  String welcome(){
return "Welcome World";
}

@RequestMapping(value="/greet", method=RequestMethod.GET)
public String greet(){
return "Greett World";
}

}

Step 1  :create a dynamic web project with tomcat as runtime
=======

Step 2  :add spring jar files in lib directory of dynamic web project or tomcat
=======

Step 3  :configure Disptcher Servlet in web.xml with some name ex. spring and
=======  It should be loaded and instantinated at the time of starting the web application 
         Internally it search the spting config file with spring-servlet.xml
         
         


Step 4 :Create spring configuration file spring-servlet.xml
======
        

  <servlet>
  <servlet-name>spring</servlet-name>
  <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
  <load-on-startup>1</load-on-startup>
  </servlet>
  
  
  <servlet-mapping>
  <servlet-name>spring</servlet-name>
  <url-pattern>/spring/*</url-pattern>
  </servlet-mapping>
  
  



Step 4 :Create spring configuration file spring-servlet.xml
======


spring-servlet.xml
====================
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:context="http://www.springframework.org/schema/context"
	xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
		http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-4.3.xsd">

<context:component-scan base-package="com.pradeep.spring"/>

<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
<property name="prefix" value="/WEB-INF/views/"/>
<property name="suffix" value=".jsp"/>
</bean>

</beans>


To create Root Web applicationContext add below tag in web.xml
=================================================================
   
   <listener>
   <listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>
   </listener>
         
                                       
    By default it search applicationContext.xml  
      


      
To create Servlet Web applicationContext add below tag in web.xml
=================================================================
  <servlet>
  <servlet-name>spring</servlet-name>
  <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
  <load-on-startup>1</load-on-startup>
  </servlet>
  
  
  <servlet-mapping>
  <servlet-name>spring</servlet-name>
  <url-pattern>/spring/*</url-pattern>
  </servlet-mapping>
  
  
 By default it search  DS-Name-servlet.xml  (spring-servlet.xml)



13-Feb-2021
================

Spring Boot
============
1.Spring Boot is an open source Java-based framework used to create a Micro Service.
2.It is developed by Pivotal Team.
3.It is easy to create a stand-alone and production ready spring applications using Spring Boot.
4. Spring Boot contains a comprehensive infrastructure support for developing a micro service 
   and enables you to develop enterprise-ready applications that you can “just run”.



What is Micro Service?
========================
Micro Service is an architecture that allows the developers to develop and deploy services independently.
Each service running has its own process and this achieves the lightweight model to support business applications.


Micro services offers the following advantages to its developers −
==================================================================
Easy deployment
Simple scalability
Compatible with Containers
Minimum configuration
Lesser production time


What is Spring Boot?
=====================
1.Spring Boot provides a good platform for Java developers to develop a stand-alone and 
production-grade spring application that you can just run.
2.You can get started with minimum configurations without the need for an entire Spring configuration setup.

Spring Boot offers the following advantages to its developers −
=================================================================
1.Easy to understand and develop spring applications
2.Increases productivity
3.Reduces the development time

Goals
======
1.To avoid complex XML configuration in Spring
2.To develop a production ready Spring applications in an easier way
3.To reduce the development time and run the application independently
4.Offer an easier way of getting started with the application

Why Spring Boot?
================

You can choose Spring Boot because of the features and benefits it offers as given here −

1.It provides a flexible way to configure Java Beans, XML configurations, and Database Transactions.

2.It provides a powerful batch processing and manages REST endpoints.

3.In Spring Boot, everything is auto configured; no manual configurations are needed.

4.It offers annotation-based spring application

5.Eases dependency management

6.It includes Embedded Servlet Container




How does it work?
=>Spring Boot automatically configures your application based on the dependencies you have added to the project by using
 @EnableAutoConfiguration annotation. 
 
 For example, if MySQL database is on your classpath, but you have not configured any database connection, 
 then Spring Boot auto-configures an in-memory database.

=>The entry point of the spring boot application is the class contains @SpringBootApplication annotation 
   and the main method.

Spring Boot automatically scans all the components included in the project by using @ComponentScan annotation.



Spring Boot Starters
=====================
=>Handling dependency management is a difficult task for big projects. 
=>Spring Boot resolves this problem by providing a set of dependencies for developers convenience.
=>For example, if you want to use Spring and JPA for database access, 
    it is sufficient if you include spring-boot-starter-data-jpa dependency in your project.

Note that all Spring Boot starters follow the same naming pattern spring-boot-starter- *, 
  where * indicates that it is a type of the application.

Examples
Look at the following Spring Boot starters explained below for a better understanding −

1.Spring Boot Starter Actuator dependency is used to monitor and manage your application. Its code is shown below −

<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>


2.Spring Boot Starter Security dependency is used for Spring Security. Its code is shown below −

<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-security</artifactId>
</dependency>


3.Spring Boot Starter web dependency is used to write a Rest Endpoints. Its code is shown below −

<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-web</artifactId>
</dependency>
      
4.Spring Boot Starter Test dependency is used for writing Test cases. Its code is shown below −

<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-test</artifactId>
</dependency>      
      
      
Auto Configuration
====================















https://start.spring.io/



Spring Web WEB
==================
Build web, including RESTful, applications using Spring MVC. Uses Apache Tomcat as the default embedded container.

Spring Boot DevTools DEVELOPER TOOLS
=====================================
Provides fast application restarts, LiveReload, and configurations for enhanced development experience.

Spring Boot Actuator OPS
========================
Supports built in (or custom) endpoints that let you monitor and manage your application - 
such as application health, metrics, sessions, etc.

Spring Security SECURITY
=========================
Highly customizable authentication and access-control framework for Spring applications.

Spring Data JPA SQL
===================
Persist data in SQL stores with Java Persistence API using Spring Data and Hibernate.

Spring Data MongoDB NOSQL
=========================
Store data in flexible, JSON-like documents, meaning fields can vary from document to document and data structure can be changed over time.




Spring Security
================
Default username :user
Password         :generated on console


To customize it
================

add below properties in application.properties
==============================================

spring.security.user.name=pradeep
spring.security.user.password==pradeep



https://docs.spring.io/spring-boot/docs/current/reference/html/production-ready-features.html




JAAS
====
Java Authentication and Authorization Service

Authentication
================
1.BASIC  (Before Spring Boot 2.x)
2.DIGEST
3.FORM BASED (From Spring Boot 2.x)



Authorization (role)
====================




To Customize default JAAS


We should write a configuration class by extending WebSecurityConfigureerAdapter and override configure methods.




@Configuration
public class BankConfig  extends WebSecurityConfigurerAdapter{

	@Autowired
	private DataSource dataSource;
	
	
	public BankConfig() {
	System.out.println("==========BankConfig created=================");
	}
	
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		System.out.println("==========BankConfig created  AuthManagerBuilder=================");
		//super.configure(auth);
	
		
		/*
		 * auth.inMemoryAuthentication()
		 * .withUser("RAM").password("{noop}RAM").roles("ADMIN").and()
		 * .withUser("RAHIM").password("{noop}RAHIM").roles("STUDENT").and()
		 * .withUser("DAVID").password("{noop}DAVID").roles("TEACHER");
		 * 
		 * 
		 */
		
		auth.jdbcAuthentication()
		    .passwordEncoder(new BCryptPasswordEncoder())
		    .dataSource(dataSource);
		
	}
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		System.out.println("==========BankConfig created  HttpSecurity=================");
		//super.configure(http);  Default is Form Based
		
		
		http.authorizeRequests()
		.antMatchers("/rest/*").permitAll()
		.antMatchers("/rest/*").denyAll()
		.antMatchers("/spring/*").hasRole("ADMIN")
		.antMatchers("/spring/welcome","/spring/today").hasRole("STUDENT")
		.antMatchers("/spring/hello","/spring/greet").hasAnyRole("ADMIN","TEACHER")
	
		
		    .anyRequest()
		    .authenticated()
		    .and()
		    .formLogin();//  Form Based
		    //.httpBasic();// Basic Auth
		
		
		
	}
	
	
	
}
















