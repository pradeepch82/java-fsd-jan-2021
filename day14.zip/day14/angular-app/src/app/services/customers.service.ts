import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'  //indicates that this service is available for entire module
})
export class CustomersService {

private baseURL="http://localhost:1213/bank-app-v1/rest/customers";

  constructor(private http:HttpClient) {
    console.log("===========PostsService created===============");
   }


   getAllCustomers():Observable<any>{
     return this.http.get(this.baseURL);
   }

  getCustomerById(customerId:number):Observable<any>{
     return this.http.get(this.baseURL+"/"+customerId);
  }

  deleteCustomerById(customerId:number):Observable<any>{
    return this.http.delete(this.baseURL+"/"+customerId);
 }


 updateCustomerById(customerId:number,customer:any):Observable<any>{
  return this.http.put(this.baseURL+"/"+customerId,customer);
}

addCustomer(customer:any):Observable<any>{
  return this.http.post(this.baseURL,customer);
}

}
