package com.pradeep.bank.presentation;

import com.pradeep.bank.dao.MapCustomerDaoImpl;
import com.pradeep.bank.model.Customer;
import com.pradeep.bank.service.CustomerService;
import com.pradeep.bank.service.MapCustomerServiceImpl;

public class CustomerMainApp {


	
private CustomerService cs;  //dependency


public CustomerMainApp() {
System.out.println("====CustomerMainApp  created==========");
}


public CustomerMainApp(CustomerService cs) //constructor injection
{
	this.cs = cs;
	System.out.println("====CustomerMainApp  param constructor==========");
}


public void setCs(CustomerService cs)// setter injection
{
	this.cs = cs;
	System.out.println("====CustomerMainApp  setCs method...==========");

}

public void addCustomer(Customer customer) {
	
	if(cs.saveCustomer(customer))
		System.out.println("Customer with Id ["+customer.getCustomerId()+"] added successfully");
	else 
		System.out.println("Problem in insertion");

}

public void updateCustomer(Customer customer) {
	
	if(cs.updateCustomer(customer))
		System.out.println("Customer with Id ["+customer.getCustomerId()+"] updated successfully");
	else 
		System.out.println("Customer doesn't exist");

}


public void deleteCustomer( int customerId) {
	
	if(cs.deleteCustomer(customerId))
		System.out.println("Customer with Id ["+customerId+"] deleted successfully");
	else 
		System.out.println("Customer doesn't exist");

}


public void showCustomer(int customerId) {
	
	Customer c=cs.findCustomer(customerId);
	
	if(c!=null)
		System.out.println("Customer with Id ["+customerId+"] Details\n===================="+c);
	
	else 
		System.out.println("Customer doesn't exist");

}


public void showAllCustomers() {
	
	System.out.println("============================================================");
	System.out.println("              Customer Details                              ");
	System.out.println("============================================================");
	for(Customer c:cs.findAllCustomers())
		System.out.println(c);
}


public static void main(String[] args) {
	
	
	MapCustomerDaoImpl mcdi=new MapCustomerDaoImpl();
	
	MapCustomerServiceImpl mcsi=new MapCustomerServiceImpl();//injection
	
	mcsi.setCustomerDao(mcdi);//setter injection
	
	CustomerMainApp cma=new CustomerMainApp(); //constructor injection
	cma.setCs(mcsi); //setter injection
	
	
	cma.showAllCustomers();
		
	
}

	
	
}
