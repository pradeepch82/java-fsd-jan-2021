package com.pradeep.bank.model;

import java.io.Serializable;

public class Account implements Serializable{

}
