import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'  //indicates that this service is available for entire module
})
export class CommentsService {

private baseURL="http://jsonplaceholder.typicode.com/comments";

  constructor(private http:HttpClient) {
    console.log("===========CommentsService created===============");
   }


   getAllComments():Observable<any>{
     return this.http.get(this.baseURL);
   }

  getAllCommentsByPostId(postId:number):Observable<any>{
     return this.http.get(this.baseURL+"?postId="+postId);
  }

  getCommentById(commentId:number):Observable<any>{
     return this.http.get(this.baseURL+"/"+commentId);
  }
 
}
