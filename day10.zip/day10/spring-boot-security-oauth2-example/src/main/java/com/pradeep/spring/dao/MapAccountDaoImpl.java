package com.pradeep.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.pradeep.spring.datasource.AccountMap;
import com.pradeep.spring.model.Account;

@Component
//@Repository("mapAccountDaoImpl")
public class MapAccountDaoImpl implements AccountDao {

	
	public MapAccountDaoImpl() {
	System.out.println("MapAccountDaoImpl created.....");
	}
	
	
	
	
	
	@Override
	public boolean addAccount(Account account) {

		AccountMap.INSTANCE.getMap().put(account.getAccno(), account);
		return true;
	}

	@Override
	public boolean deleteAccount(int accno) {
		if(	AccountMap.INSTANCE.getMap().containsKey(accno))
		{
			AccountMap.INSTANCE.getMap().remove(accno);
		return true;
		}
				return false;
	}

	@Override
	public Account getAccount(int accno) {
		return AccountMap.INSTANCE.getMap().get(accno);
	}

	@Override
	public boolean deposit(int accno, double amount) {
		if(	AccountMap.INSTANCE.getMap().containsKey(accno))
		{
			AccountMap.INSTANCE.getMap().get(accno).deposit(amount);
		return true;
		}
		return false;
	}

	@Override
	public boolean withdraw(int accno, double amount) {
		if(	AccountMap.INSTANCE.getMap().containsKey(accno))
		{
			AccountMap.INSTANCE.getMap().get(accno).withdraw(amount);
		return true;
		}
		return false;
	}

	@Override
	public boolean updateAccount(Account account) {
		AccountMap.INSTANCE.getMap().put(account.getAccno(), account);
		return true;
	}
	
	@Override
	public List<Account> getAccountList() {
		return  new ArrayList<>(AccountMap.INSTANCE.getMap().values());
	}
	
	
}
