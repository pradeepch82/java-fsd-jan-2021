package com.pradeep.spring.dao;

import java.util.List;

import com.pradeep.spring.model.Account;

public interface AccountDao {

	boolean addAccount(Account account);
	boolean updateAccount(Account account);
	
	boolean deleteAccount(int accno);
	Account getAccount(int accno);
	boolean deposit(int accno,double amount);
	boolean withdraw(int accno,double amount);
	List<Account> getAccountList();
	
}
