package com.pradeep.bank.dao;

import java.util.List;

import com.pradeep.bank.model.Customer;

public interface CustomerDao {
	
	
	boolean  saveCustomer(Customer customer);
	boolean  updateCustomer(Customer customer);
	boolean  deleteCustomer(int customerId);
	List<Customer> findAllCustomers();
	Customer   findCustomer(int customerId);
		

}
