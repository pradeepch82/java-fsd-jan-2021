package com.pradeep.bank.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.pradeep.bank.model.Customer;

public class CustomerRowMapper implements RowMapper<Customer> {

	
	
	public CustomerRowMapper() {
	System.out.println("======================CustomerRowMapper created=============");
	}
	
	
	@Override
	public Customer mapRow(ResultSet rs, int rowindex) throws SQLException {

		System.out.println("............In mapRow.........");
		Customer c = new Customer();

		c.setCustomerId(rs.getInt(1));
		c.setName(rs.getString(2));
		c.setPan(rs.getString(3));
		c.setMobile(rs.getString(4));
	
		c.setDateOfBirth(rs.getDate(6));
		c.setAddress(rs.getString(7));

		return c;
	}

}
