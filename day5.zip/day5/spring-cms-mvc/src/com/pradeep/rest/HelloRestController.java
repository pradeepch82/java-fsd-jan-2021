package com.pradeep.rest;

import java.util.Date;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class HelloRestController {

	
	public HelloRestController() {
	System.out.println("===========HelloRestController created============");
	}

    @GetMapping
	public String helloGet() {
		return "HelloRestController   :helloGET";
	}
    
    @PostMapping
	public String helloPost() {
		return "HelloRestController   :helloPOST";
	}
    

    @PutMapping
   	public String helloPut() {
   		return "HelloRestController   :helloPUT";
   	}
       
    
    @DeleteMapping
   	public String helloDelete() {
   		return "HelloRestController   :helloDELETE";
   	}
       
    
    @PatchMapping
   	public String helloPatch() {
   		return "HelloRestController   :helloPATCH";
   	}
       

    @GetMapping("/today")
    public String todayTest() {
		return  "HelloRestController :Hi All,Today is "+new Date();
				
	}
	
	
	
    
    
}
