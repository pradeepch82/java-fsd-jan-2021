import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers:[UsersService]
})
export class UsersComponent implements OnInit {

  title="All Users";
  user:any;
  message="";
  userId=0;
  constructor(private us:UsersService,private route:ActivatedRoute) {
    console.log("==========UsersComponent created=============");
  }

  ngOnInit(): void {

    this.userId=this.route.snapshot.params.user_id;
    
    if(this.userId)
    {
      this.title="User Details with id ["+this.userId+"]";
      this.getUserById();
    }
    console.log("==========UsersComponent initialized=============");
  }

  ngOnDestroy(): void {
    console.log("==========UsersComponent destroyed=============");
  
  }


  getUserById(){
    this.us.getUserById(this.userId)
           .subscribe(response=>this.user=response,error=>this.message=error);
  }


}
