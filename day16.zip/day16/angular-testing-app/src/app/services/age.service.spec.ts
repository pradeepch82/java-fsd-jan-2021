import { TestBed } from '@angular/core/testing';

import { AgeService } from './age.service';

describe('AgeService', () => {
  let service: AgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Should return fale for age below range :15', () => {
    expect(service.validateAge(15)).toBeFalse();
  });

it('Should return false for age above range :65', () => {
    expect(service.validateAge(65)).toBeFalse();
  });
  
  it('Should return false for age with lower boundry :20', () => {
    expect(service.validateAge(20)).toBeTruthy();
  });

  it('Should return false for age with upper boundry :60', () => {
    expect(service.validateAge(60)).toBeTruthy();
  });

  it('Should return false for age within range :45', () => {
    expect(service.validateAge(45)).toBeTruthy();
  });

});
