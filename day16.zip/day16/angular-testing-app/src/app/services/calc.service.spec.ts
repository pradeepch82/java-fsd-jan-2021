import { TestBed } from '@angular/core/testing';

import { CalcService } from './calc.service';

describe('CalcService', () => {
  let service: CalcService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalcService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return add(10,5) as 15', () => {
    expect(service.add(10,5)).toEqual(15);
  });

 it('should return sub(10,5) as 5', () => {
    expect(service.sub(10,5)).toEqual(5);
  });
  
  xit('should return mul(10,5) as 50', () => {
    expect(service.mul(10,5)).toEqual(50);
  });

  xit('should return div(10,5) as 2', () => {
    expect(service.div(10,5)).toEqual(2);
  });
  
  xit('should return mod(10,5) as 0', () => {
    expect(service.mod(10,5)).toEqual(0);
  });
  
});
