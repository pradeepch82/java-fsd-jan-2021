import { Component, OnInit, ViewChild } from '@angular/core';
import { BgColorDirective } from '../directives/bg-color.directive';
import { NumberComponent } from '../number/number.component';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {

  @ViewChild(NumberComponent)
  private n:any;


  @ViewChild(BgColorDirective)
  private b:any;


  @ViewChild("name")
  private name:any;

  @ViewChild("city")
  private city:any;



  constructor() { }

  ngOnInit(): void {
  }


  increase(){
  this.n.increment();

  }

  decrease(){
   this.n.decrement();
  }

  changeBgColor(){
    this.b.bgColor="lightgreen";
  }

  changeColors(){
    this.name.nativeElement.style.backgroundColor='cyan';
    this.city.nativeElement.style.backgroundColor='yellow';
    
    this.name.nativeElement.style.color='red';
    this.city.nativeElement.style.color='magenta';
    
 
  }
}
