import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'  //indicates that this service is available for entire module
})
export class PostsService {

private baseURL="http://jsonplaceholder.typicode.com/posts";

  constructor(private http:HttpClient) {
    console.log("===========PostsService created===============");
   }


   getAllPosts():Observable<any>{
     return this.http.get(this.baseURL);
   }

  getAllPostsByUserId(userId:number):Observable<any>{
     return this.http.get(this.baseURL+"?userId="+userId);
  }

  getPostById(postId:number):Observable<any>{
     return this.http.get(this.baseURL+"/"+postId);
  }
 
}
