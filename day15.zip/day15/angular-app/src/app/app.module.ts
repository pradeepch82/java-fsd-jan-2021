import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { HomeComponent } from './home/home.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { UsersComponent } from './users/users.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersService } from './services/users.service';
import { NestedComponent } from './nested/nested.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { CustomersComponent } from './customers/customers.component';
import { CountryComponent } from './country/country.component';
import { StateComponent } from './state/state.component';
import { CityComponent } from './city/city.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { BgColorDirective } from './directives/bg-color.directive';
import { FgColorDirective } from './directives/fg-color.directive';
import { ShowDirective } from './directives/show.directive';
import { HideDirective } from './directives/hide.directive';
import { NumberComponent } from './number/number.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';

@NgModule({
  declarations: [ //components,directives,pipes
    AppComponent,
    AngularBasicsComponent, 
    TechnologiesComponent, 
    HomeComponent,
    AngularPipesComponent,
    CaseStudyComponent,
    UsersComponent,
    UsersListComponent,
    UsersTableComponent,
    PostsComponent,
    CommentsComponent,
    TodosComponent,
    AlbumsComponent,
    PhotosComponent,
    NestedComponent,
    ViewChildComponent,
    LoginComponent,
    RegisterComponent,
    CustomDirectivesComponent,
    CustomersComponent,
    CountryComponent,
    StateComponent,
    CityComponent,
    ParentComponent,
    ChildComponent,
    BgColorDirective,
    FgColorDirective,
    ShowDirective,
    HideDirective,
    NumberComponent,
    GenderPipe,
    OrderByPipe
  ],
  imports: [ //modules 
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  //providers: [UsersService], //services 
providers:[],
  //bootstrap: [AppComponent,AngularBasicsComponent,TechnologiesComponent,AngularPipesComponent,HomeComponent],
  bootstrap: [AppComponent]

})
export class AppModule { }
