import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {


  title="Angular Basics";   //string

  colors=["RED","GREEN","BLUE"]; //array

  day=1;   //number
  min:number=1; //number
  max:number=8; //number

  show=true;  //boolean
  hide:boolean=false;  //boolean
  
  employee={
                id:101,
                name:'Pradeep vasant chinchole',
                salary:13429.4586654455,
                variable:0.15,
                isMarried:true,
                pan:'pmxaC9834D',
                mobile:'9158652627',
                doj:new Date() 
  };  //object



  time=new Observable<string>((s:Subscriber<string>)=>{
    setInterval(()=>{
    s.next(new Date().toLocaleString());
   },1000);

  });

  constructor() {
    console.log("==========AngularBasicsComponent created=============");
  }

  ngOnInit(): void {
    console.log("==========AngularBasicsComponent initialized=============");
  }

  ngOnDestroy(): void {
    console.log("==========AngularBasicsComponent destroyed=============");
  
  }
  
  showHide(){
    this.hide=!this.hide;
  }
}
