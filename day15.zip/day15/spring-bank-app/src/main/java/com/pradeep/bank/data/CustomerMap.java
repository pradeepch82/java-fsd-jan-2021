package com.pradeep.bank.data;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.pradeep.bank.model.Account;
import com.pradeep.bank.model.Customer;

public enum CustomerMap {

INSTANCE;
	
private Map<Integer, Customer> map;

private CustomerMap() {

this.map=new HashMap<>();

Customer c1=new Customer("Ram Joshi", "amxpc9867h", "71562276367", new Date(2011, 11, 11), "Shivane Pune");
Customer c2=new Customer("Sunil  Chinchole", "emxpc9867h", "91562276367", new Date(2011, 11, 11), "Shivane Pune");
Customer c3=new Customer("Sanjay Patil", "pmxpc9867v", "71562276365", new Date(2011, 11, 11), "Shivane Pune");
Customer c4=new Customer("Rajesh Patil", "cmxpc9867x", "81562276365", new Date(2011, 11, 11), "Shivane Pune");

map.put(c1.getCustomerId(), c1);
map.put(c2.getCustomerId(), c2);
map.put(c3.getCustomerId(), c3);
map.put(c4.getCustomerId(), c4);
}

public Map<Integer, Customer> getMap() {
	return map;
}

	
}
